package com.cg.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.spring.bean.TraineeBean;
import com.cg.spring.service.ITraineeService;

@Controller
public class TraineeController {

	@Autowired
	ITraineeService service;

	TraineeBean trainee = null;

	@RequestMapping(value="/login.htm",method=RequestMethod.POST)
	public String loginPage(@RequestParam("username") String userName,
			@RequestParam("password") String password,Model map){
		String redirect=null;
		if(userName.equals("asdf")&&password.equalsIgnoreCase("1234")){
			redirect = new String("traineemgmtsys");
		}
		else{
			redirect = new String("login");
		}
		return redirect;
	}

	@RequestMapping(value="/addtrainee.htm",method=RequestMethod.GET)
	public String showAddTrainee(Model model){
		return "addtrainee";
	}

	@RequestMapping(value="/addtrainee.htm",method=RequestMethod.POST)
	public String addTrainee(@RequestParam("id") String id,@RequestParam("tname") String name,
			@RequestParam("location") String location,@RequestParam("domain") String domain, Model model){
		String redirect = null;
		int traineeId = Integer.parseInt(id);
		trainee = new TraineeBean(traineeId,name,domain,location);
		service.addTrainee(trainee);
		model.addAttribute("message", "Trainee with "+id+" has been added successfully with location"+location);
		return "traineemgmtsys";   	
	}
	@RequestMapping(value="/retrievealltrainee.htm")
	public String viewTrainee(Model map){
		List<TraineeBean> traineeList = service.retrieveAllTrainees();
		map.addAttribute("traineeList", traineeList);
		return "retrieveall";
	}
	@RequestMapping(value="/retrieveatrainee.htm")
	public String viewATrainee(Model map){
		return "retrieveatrainee";
	}
	@RequestMapping(value="/retrieveatrainee.htm",method=RequestMethod.POST)
	public String retrieveTrainee(@RequestParam("traineeId") String traineeId,Model map){
		int id = Integer.parseInt(traineeId);
		trainee = service.retrieveTrainee(id);
		map.addAttribute("trainee", trainee);
		return "retrieveatrainee";
	}
	@RequestMapping(value="/getId.htm")
	public String removeTrainee(){
		return "delete";
	}
	@RequestMapping(value="/delete.htm",method=RequestMethod.POST)
	public String deleteTrainee(@RequestParam("traineeId") int id, Model map){
		String msg = null;  
		trainee = service.viewTraineeById(id);
		map.addAttribute("trainee", trainee);
		return "delete";
	}
	@RequestMapping(value="/deletetrainee.htm",method=RequestMethod.POST)
	public String removeTrainee(Model map){
		int id = trainee.getTraineeId();
		String msg = null;
		trainee = service.deleteTrainee(id);
		if(trainee==null){
			msg = "trainee with id "+id+" not found";
		}
		else{
			msg = "Trainee with id "+id+" deleted successfully";
		}
		map.addAttribute("message", msg);
		return "traineemgmtsys";
	}



	@RequestMapping(value="/getIdToModify.htm")
	public String getIdToModify(){
	
		return "modifytrainee";
	}

	@RequestMapping(value="/modifytrainee.htm", method = RequestMethod.POST)
	public String updateTrainee(@RequestParam("traineeId") int id,@RequestParam("traineeName") String name,
			@RequestParam("location") String location, @RequestParam("domain") String domain,
			Model map){
	
		TraineeBean trainee = new TraineeBean(id,name,domain,location);
		trainee = service.updateTrainee(trainee);
		String msg = null;
		if(trainee==null){
			msg = "This trainee DNE";
		}
		else{
			msg = "Details updated";
		}
		map.addAttribute("message", msg);
		return "traineemgmtsys";
	}

	@RequestMapping(value="/updatetrainee.htm", method = RequestMethod.POST)
	public String modifyTrainee(@RequestParam("traineeId") int traineeId,Model map){
		trainee = service.viewTraineeById(traineeId);
		map.addAttribute("trainee", trainee);
		return "modifytrainee";
	}
}