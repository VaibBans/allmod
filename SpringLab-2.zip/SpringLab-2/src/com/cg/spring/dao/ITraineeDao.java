package com.cg.spring.dao;

import java.util.List;

import com.cg.spring.bean.TraineeBean;


public interface ITraineeDao {

	public abstract TraineeBean addTrainee(TraineeBean trainee);
	public abstract TraineeBean retrieveTrainee(int traineeId);
	public abstract List<TraineeBean> retrieveAllTrainees();
	public abstract TraineeBean deleteTrainee(int traineeId);
	public abstract TraineeBean updateTrainee(TraineeBean trainee);
	public abstract TraineeBean viewTraineeById(int traineeId);
}